| Supported Targets | ESP32-P4 |
| ----------------- | -------- |


# Human Face Detect Example

### Interaction

#### ESP-S3-EYE

Physical buttons

| btn  | opertion         |
|------|------------------|
| play | recognize        |
| up   | enroll           |
| down | delete last feat |

#### ESP32-P4-Function-EV-Board

Touch screen buttons

| btn       | opertion         |
|-----------|------------------|
| recognize | recognize        |
| enroll    | enroll           |
| delete    | delete last feat |

